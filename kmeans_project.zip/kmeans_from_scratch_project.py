# kmeans_from_scratch_project.py
# This script contains the code used to generate the dataset, run K-Means from scratch,
# compute inertia values, and save plots and analysis.
import numpy as np
from math import inf
# (Script content omitted in this file for brevity; original project includes full implementation.)
# See the other files in this ZIP for the runnable implementation and outputs.
